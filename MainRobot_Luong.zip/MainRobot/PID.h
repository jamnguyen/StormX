#ifndef __PID_H__
#define __PID_H__

#define rotate_Kp  4
#define rotate_Ki 1
#define rotate_Kd  10
extern float rotate_last_error;
int PID_rotate(float error);

#define wall_Kp  1.5f
#define wall_Ki  0.0f
#define wall_Kd  10.0f /// to be compensated by PID dirrection


int PID_move_wall(float wall_error);

#define direction_Kp  3
#define direction_Ki  0.1
#define direction_Kd  20
int PID_move_dirrection(float error);


#endif
