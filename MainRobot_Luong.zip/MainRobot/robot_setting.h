#ifndef ___ROBOT_SETTING
#define ___ROBOT_SETTING

#define MODE_1       1
#define MODE_2       0
//
//#define HEAD_LEFT   2
//#define HEAD_RIGHT  3
//
#define SERVO_PIN 12

#define HEAD_LEFT_PIN   7
#define HEAD_RIGHT_PIN  8
#define WORKING_MODE_PIN  11

#define MOVE_LEFT_UP    6
#define MOVE_LEFT_DOWN  5
#define MOVE_RIGHT_UP   10
#define MOVE_RIGHT_DOWN 9

#define SIDE_LEFT   1
#define SIDE_RIGHT  0
#define SIDE_BACK   2

#define HEAD_OFFSET 10
#define LEFT_SIDE_OFFSET  7
#define RIGHT_SIDE_OFFSET 7  
#define MOVE_FW_SPEED 80
#define MOVE_BW_SPEED 80

#define FPS 20
#define FTIME  1000/FPS

#define DEBUG
#define USE_SOFT_SERIAL

/// Moving state:
#define STATE_MOVE_UP             1
#define STATE_CHECK               2
#define STATE_MOVE_BACK           3
#define STATE_ROTATE_LEFT         4
#define STATE_UTURN               5
#define STATE_MOVE_LEFT           6
#define STATE_ROTATE_RIGHT        7     // Rotate right and then move up
#define STATE_ROTATE_RIGHT_CORNER 8
#define STATE_PUSH_BALL           9
#define STATE_STUCK_BALL_GO_BACK  10
#define STATE_ROTATE_RIGHT2       11    // Rotate right and move right
#define STATE_MOVE_RIGHT          12    // Move right until hit wall
#define STATE_ROTATE_LEFT_CONRNER 13



#endif
