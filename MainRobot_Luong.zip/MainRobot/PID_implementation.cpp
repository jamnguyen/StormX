#include <Arduino.h>
#include <Wire.h>
#include "PID.h"

/// Internal variable 
// :private
float rotate_integral;
float rotate_last_error;
float wall_last_error;

int PID_rotate(float error)
{
  if ((error < 5) && (error > -5))
  {
    rotate_integral += error;
  }
  if (rotate_integral * error < 0)
  {
    rotate_integral = 0;
  }

  int result = rotate_Kp * error +  rotate_Ki * rotate_integral + rotate_Kd * (error - rotate_last_error);
  rotate_last_error = error;
  /// Validate result
  result = constrain(result, -120, 120);
  return result;
}

int PID_move_wall(float wall_error)
{
  int result = wall_Kp * wall_error + wall_Kd * (wall_error - wall_last_error) ; // skip Ki and Kd elements
  wall_last_error = wall_error;
  result = constrain(result, -20, 20);
  return result;
}



int PID_move_dirrection(float error)
{
  if ((error < 5) && (error > -5))
  {
    rotate_integral += error;
  }
  if (rotate_integral * error < 0)
  {
    rotate_integral = 0;
  }

  int result = direction_Kp * error +  direction_Ki * rotate_integral + direction_Kd * (error - rotate_last_error);
  rotate_last_error = error;

  result = constrain(result, -25, 25);
  return result;
}

