#ifndef MAINROBOTH
#define MAINROBOTH

struct compass_setting_data
{
  float compass_x_offset, compass_y_offset, compass_z_offset;
  float compass_x_gainError, compass_y_gainError, compass_z_gainError;
};

#define DIRECTION_UP_CENTER 0
#define DIRECTION_UP_LEFT   1
#define DIRECTION_UP_RIGHT  2
#define DIRECTION_LEFT      3
#define DIRECTION_RIGHT     4
#define DIRECTION_DOWN_L    5
#define DIRECTION_DOWN_R    6

static const PROGMEM String direction_name[7] =
{
  "Up_C",
  "Up L",
  "Up R",
  "Left",
  "Right",
  "Down_L",
  "Down_R"
};

struct base_direction_data
{
  float directions[8];
};

struct robot_setting_data
{
  uint16_t moving_speed;
  uint8_t  moving_step;
  uint8_t isEnable_puzzer;
};
float get_base_dirrection(int current_direction);
void read_eep_compass_setting(float& x_offset,  float& y_offset , float& z_offset, float& x_gainError, float& y_gainError , float& z_gainError);
void init_compass();
void init_distance_sensor();
void limit_fps();
void update_sensors();
int get_working_mode();
void debug_output();
void calibrate_sensor();
bool update_rotate_right_corner(float error);
bool push_ball();
void save_eep(int mode);
void load_eep(int mode);
void   reset_key();
void update_key();
void push_state(int state, int _delay = 100);
int auto_detect_base_dirrection();

#endif
